  function increase(btn) {
      btn.textContent = Number(btn.textContent) + 1;
  }